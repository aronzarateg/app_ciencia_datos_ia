# -*- coding: utf-8 -*-
"""Limpieza tecnica conservadora del CSV publico INDECI 2003-2025.
No se imputan faltantes, no se suprimen ceros, extremos o codigos reiterados.
"""
from pathlib import Path
import pandas as pd
import numpy as np
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.dimensions import ColumnDimension
from zipfile import ZipFile, ZIP_DEFLATED
from collections import Counter

ROOT=Path('/mnt/data')
SOURCE=ROOT/'BD_2003-2025_EMERGENCIAS.csv'
OUTPUT_FULL=ROOT/'INDECI_2003_2025_LIMPIA_COMPLETA.csv'
OUTPUT_NAT=ROOT/'INDECI_2003_2025_LIMPIA_ORIGEN_NATURAL.csv'
OUTPUT_REPORT=ROOT/'INDECI_2003_2025_CONTROL_LIMPIEZA.xlsx'
OUTPUT_ZIP=ROOT/'INDECI_2003_2025_DATOS_LIMPIOS.zip'

original=pd.read_csv(SOURCE,sep=';',encoding='latin1',dtype=str,keep_default_na=False,low_memory=False)
assert original.shape==(142139,49),f'Unexpected shape {original.shape}'
rows0,cols0=original.shape
orig_cols=list(original.columns)
D=original.copy()
trim_count={c:int((D[c]!=D[c].str.strip()).sum()) for c in D.columns}
for c in D.columns:
    D[c]=D[c].str.strip()

# ISO date: the 2003-2024 export uses DD/MM/YYYY; the 2025 export uses MM/DD/YY.
year=D['AÑO'].astype(int)
mask_old=year.lt(2025)
mask_new=year.eq(2025)
assert (mask_old|mask_new).all()
s=pd.Series(index=D.index,dtype='datetime64[ns]')
s.loc[mask_old]=pd.to_datetime(D.loc[mask_old,'FECHA  DE LA EMER'],format='%d/%m/%Y',errors='coerce')
s.loc[mask_new]=pd.to_datetime(D.loc[mask_new,'FECHA  DE LA EMER'],format='%m/%d/%y',errors='coerce')
assert s.notna().all(),'Some dates did not parse'
assert (s.dt.year.to_numpy()==year.to_numpy()).all(),'Year discrepancy'
months={'ENERO':1,'FEBRERO':2,'MARZO':3,'ABRIL':4,'MAYO':5,'JUNIO':6,'JULIO':7,'AGOSTO':8,'SETIEMBRE':9,'OCTUBRE':10,'NOVIEMBRE':11,'DICIEMBRE':12}
assert (s.dt.month.to_numpy()==D['MES'].map(months).to_numpy()).all(),'Month discrepancy'
D['FECHA  DE LA EMER']=s.dt.strftime('%Y-%m-%d')
# Readable date header; other original column names retained apart from extraneous edge spaces.
D.columns=[('FECHA_EMERGENCIA' if c=='FECHA  DE LA EMER' else c.strip()) for c in D.columns]
D['FILA_ORIGEN_CSV']=np.arange(2,len(D)+2,dtype=np.int64)
assert len(D)==rows0 and len(D.columns)==50
assert D['FILA_ORIGEN_CSV'].is_unique
# Preserve ubigeo leading zero and binary counts exactly as received.
assert (D['COD. DISTRITO'].str.len()==6).all()
numcols=list(orig_cols[11:])
for oldc in numcols:
    c=oldc.strip()
    v=D[c]
    n=pd.to_numeric(v.replace('',np.nan),errors='coerce')
    assert (~((v!='') & n.isna())).all(),f'Unexpected non numeric token in {c}'
assert D.duplicated(subset=D.columns[:-1]).sum()==0

natural=D.loc[D['TIPO DE PELIGRO']=='ORIGEN NATURAL'].copy()
assert len(natural)==106301
assert len(D)-len(natural)==35838
D.to_csv(OUTPUT_FULL,sep=';',index=False,encoding='utf-8-sig')
natural.to_csv(OUTPUT_NAT,sep=';',index=False,encoding='utf-8-sig')

# Report tabular results with exact source row references.
wb=Workbook()
ws=wb.active
ws.title='Resumen'
NAVY='073967';BLUE='195D8A';LIGHT='EAF1F7';YELLOW='F8BE14';DARK='172A3A';GREEN='147D63';AMBER='9A5C00'

def create_sheet(name,headers,rows):
    w=wb.create_sheet(name)
    w.append(headers)
    for r in rows: w.append([None if v is pd.NA else v for v in r])
    w.freeze_panes='A2'
    w.auto_filter.ref=w.dimensions
    return w

items=[
('Archivo fuente',SOURCE.name),('Institucion', 'INDECI - datos abiertos de emergencias y danos'),
('Filas originales',rows0),('Columnas originales',cols0),
('Filas en version completa',len(D)),('Filas origen natural',len(natural)),
('Filas inducidas por accion humana',len(D)-len(natural)),
('Filas descartadas',0),('Duplicados exactos detectados',int(original.duplicated().sum())),
('Codigos SINPAD no unicos (codigos)',int(D['CODIGO DE EMERGENCIA-SINPAD'].value_counts().gt(1).sum())),
('Registros con codigo SINPAD repetido',int(D['CODIGO DE EMERGENCIA-SINPAD'].duplicated(keep=False).sum())),
('Fechas invalidas',int(s.isna().sum())),
('Fechas con mes/ano discrepante',0),
('Celdas de texto con espacios exteriores normalizados',sum(trim_count.values())),
('Valores perdidos rellenados',0),
('Ceros eliminados',0),
('Costos de ayuda negativos por revisar',int((pd.to_numeric(D['COSTO DE LA AYUDA'])<0).sum())),
('Conteos de ganado no enteros por revisar',sum(int(((pd.to_numeric(D[c],errors='coerce').dropna()%1)!=0).sum()) for c in ['PERDIDA VACUNO','AFECTADOS VACUNO','PERDIDA CAMELIDO','AFECTADOS CAMELIDO','PERDIDA CAPRINO','AFECTADOS CAPRINO','PERDIDA PORCINO','AFECTADOS PORCINO','PERDIDA DE ANIMALES MENORES','AFECTA DE ANIMALES MENORES'])),
('Enlace oficial','https://www.datosabiertos.gob.pe/dataset/emergencias-y-da%C3%B1os-nivel-nacional-por-departamento'),
]
ws.append(['INDICADOR','RESULTADO'])
for row in items:ws.append(row)
ws.freeze_panes='A2'

create_sheet('Bitacora',['ACCION','DESCRIPCION','CONSECUENCIA'],[
('Lectura','CSV separado por punto y coma y codificado Latin-1. Todas las columnas leidas inicialmente como texto.','Evita perdida de ceros iniciales en codigos UBIGEO.'),
('Espacios','Se eliminaron espacios al principio y al final de campos de texto (87 registros en DIST.).','No se altero el contenido sustantivo.'),
('Fecha 2003-2024','Fechas de 2003 a 2024 parseadas como DD/MM/YYYY.','Convertidas a YYYY-MM-DD.'),
('Fecha 2025','Fechas 2025 parseadas como MM/DD/YY.','Convertidas a YYYY-MM-DD.'),
('Nombres de variables','Se renombro FECHA  DE LA EMER a FECHA_EMERGENCIA y se eliminaron espacios al final de encabezados.','Las otras columnas mantienen los nombres originales.'),
('Trazabilidad','Se agrego FILA_ORIGEN_CSV con el numero de fila del CSV original, empezando por 2.','Permite rastrear anomalias sin perder casos.'),
('Valores faltantes','Se conservaron como campos vacios.','No se imputaron ceros ni valores medios.'),
('Ceros y extremos','Se preservaron valores cero y valores extremos.','No se adulteraron resultados.'),
('Codigos repetidos','Se conservaron todos los registros con SINPAD repetido.','Difieren en fecha, anio o lugar; requieren revision.'),
('Costo negativo','No se reemplazo el costo negativo.','Marcado en hoja Costos_negativos para verificacion de fuente.'),
('Conteos fraccionarios','No se redondearon conteos fraccionarios de ganado.','Marcados en hoja Ganado_fraccionario.'),
('Origen natural','Se genero un segundo archivo filtrado por el valor literal ORIGEN NATURAL.','No se reinterpretaron categorias del INDECI.'),
('Aprendizaje automatico','Todavia no se aplico imputacion/one-hot/escalado/split.','Esto debe ajustarse SOLO con datos de entrenamiento para evitar fuga de informacion.'),
])

missing=[]
for oldc in orig_cols:
    c='FECHA_EMERGENCIA' if oldc=='FECHA  DE LA EMER' else oldc.strip()
    series=D[c]
    v=pd.to_numeric(series.replace('',np.nan),errors='coerce') if oldc in numcols else None
    missing.append([c,'Numerica' if oldc in numcols else ('Fecha' if c=='FECHA_EMERGENCIA' else 'Categorica/codigo'),int(series.eq('').sum()),round(100*series.eq('').mean(),2),int(series.eq('0').sum()),int(series.nunique()),'' if v is None else int(v.lt(0).sum())])
create_sheet('Valores_perdidos',['VARIABLE','TIPO APROXIMADO','VACIOS','VACIOS %','CEROS LITERALES','VALORES UNICOS','NEGATIVOS'],missing)

ids=D['CODIGO DE EMERGENCIA-SINPAD']
rep=D.loc[ids.duplicated(keep=False),['FILA_ORIGEN_CSV','CODIGO DE EMERGENCIA-SINPAD','FECHA_EMERGENCIA','AÑO','DPTO.','PROV.','DIST.','PELIGRO','DAMNIFICADOS']].sort_values(['CODIGO DE EMERGENCIA-SINPAD','FECHA_EMERGENCIA'])
create_sheet('SINPAD_repetidos',list(rep.columns),rep.itertuples(index=False,name=None))
neg=D.loc[pd.to_numeric(D['COSTO DE LA AYUDA'])<0,['FILA_ORIGEN_CSV','CODIGO DE EMERGENCIA-SINPAD','FECHA_EMERGENCIA','DPTO.','PELIGRO','COSTO DE LA AYUDA']]
create_sheet('Costos_negativos',list(neg.columns),neg.itertuples(index=False,name=None))
fracrows=[]
ganado=['PERDIDA VACUNO','AFECTADOS VACUNO','PERDIDA CAMELIDO','AFECTADOS CAMELIDO','PERDIDA CAPRINO','AFECTADOS CAPRINO','PERDIDA PORCINO','AFECTADOS PORCINO','PERDIDA DE ANIMALES MENORES','AFECTA DE ANIMALES MENORES']
for k in ganado:
    n=pd.to_numeric(D[k],errors='coerce')
    for row in D.loc[n.notna()&n.mod(1).ne(0),['FILA_ORIGEN_CSV','CODIGO DE EMERGENCIA-SINPAD','FECHA_EMERGENCIA','PELIGRO',k]].itertuples(index=False,name=None):
        fracrows.append((*row[:-1],k,row[-1]))
create_sheet('Ganado_fraccionario',['FILA_ORIGEN_CSV','SINPAD','FECHA','PELIGRO','VARIABLE','VALOR ORIGINAL'],fracrows)

ub=D.groupby('COD. DISTRITO')['DIST.'].nunique()
problem_codes=ub[ub.gt(1)].index
ub_rows=[]
for code in problem_codes:
    subset=D[D['COD. DISTRITO']==code]
    for dist,n in subset['DIST.'].value_counts().items():
        ub_rows.append([code,subset['DPTO.'].iloc[0],subset['PROV.'].iloc[0],dist,int(n)])
create_sheet('Ubigeo_verificar',['CODIGO DISTRITO','DEPARTAMENTO','PROVINCIA','DISTRITO REPORTADO','FRECUENCIA'],ub_rows)

counts=D.groupby(['AÑO','TIPO DE PELIGRO']).size().unstack(fill_value=0)
counts=counts.reindex(columns=['ORIGEN NATURAL','INDUCIDOS POR LA ACCIÓN HUMANA'],fill_value=0)
yearrows=[]
for y,vals in counts.sort_index().iterrows():
    yearrows.append([int(y),int(vals.iloc[0]),int(vals.iloc[1]),int(sum(vals))])
create_sheet('Conteos_por_ano',['AÑO','ORIGEN NATURAL','ORIGEN HUMANO','TOTAL'],yearrows)

mapping=[]
for i,c in enumerate(orig_cols,1):
    mapped=('FECHA_EMERGENCIA' if c=='FECHA  DE LA EMER' else c.strip())
    role='Fecha ISO' if i==2 else ('Conteo/medida numerica' if i>=12 else 'Identificador o categoria')
    mapping.append([i,c,mapped,role])
mapping.append([50,'(No existia)','FILA_ORIGEN_CSV','Identificador fila de la fuente'])
create_sheet('Equivalencia_columnas',['NUMERO','COLUMNA ORIGINAL','COLUMNA LIMPIA','USO'],mapping)

# Professional, legible formatting. Report is small and contains no derived worksheet formulas.
for w in wb.worksheets:
    w.sheet_view.showGridLines=False
    w.sheet_properties.pageSetUpPr.fitToPage=True
    for cell in w[1]:
        cell.font=Font(name='Aptos',size=10,bold=True,color='FFFFFF')
        cell.fill=PatternFill('solid',fgColor=NAVY)
        cell.alignment=Alignment(vertical='center',wrap_text=True)
    w.row_dimensions[1].height=36
    for row in w.iter_rows(min_row=2):
        for cell in row:
            cell.font=Font(name='Aptos',size=10,color=DARK)
            cell.alignment=Alignment(vertical='center',wrap_text=True)
            if cell.row%2==0: cell.fill=PatternFill('solid',fgColor='F2F6FA')
        w.row_dimensions[row[0].row].height=31 if w.title in ('Bitacora','Resumen') else 22
    for j,col in enumerate(w.columns,1):
        header=str(w.cell(1,j).value or '')
        width={'Resumen':{1:53,2:75},'Bitacora':{1:26,2:83,3:73},'Valores_perdidos':{1:41,2:24},'Equivalencia_columnas':{1:12,2:42,3:42,4:27}}.get(w.title,{}).get(j,None)
        if width is None:
            maxlen=max(len(str(cell.value or '')) for cell in list(col)[:100])
            width=max(14,min(44,max(maxlen+3,len(header)+3)))
        w.column_dimensions[get_column_letter(j)].width=width
    w.print_options.horizontalCentered=True
    w.sheet_properties.outlinePr.summaryBelow=True
    w.freeze_panes='A2'
wb.save(OUTPUT_REPORT)

# Round-trip verification of content, dates and conservation of rows.
full_test=pd.read_csv(OUTPUT_FULL,sep=';',encoding='utf-8-sig',dtype=str,keep_default_na=False,low_memory=False)
nat_test=pd.read_csv(OUTPUT_NAT,sep=';',encoding='utf-8-sig',dtype=str,keep_default_na=False,low_memory=False)
assert len(full_test)==len(D) and len(nat_test)==len(natural)
assert list(full_test.columns)==list(D.columns)
assert full_test.equals(D.astype(str)) or full_test.equals(D.assign(FILA_ORIGEN_CSV=D['FILA_ORIGEN_CSV'].astype(str)))
assert (nat_test['TIPO DE PELIGRO']=='ORIGEN NATURAL').all()
assert int((full_test['DAMNIFICADOS']=='0').sum())==88365
assert sum(nat_test['DAMNIFICADOS'].ne('0'))==29653
assert wb.sheetnames[0]=='Resumen'
with ZipFile(OUTPUT_ZIP,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for path in [OUTPUT_FULL,OUTPUT_NAT,OUTPUT_REPORT,ROOT/'limpiar_indeci.py']:
        z.write(path,arcname=path.name)
for p in [OUTPUT_FULL,OUTPUT_NAT,OUTPUT_REPORT,OUTPUT_ZIP]:
    print(p.name,round(p.stat().st_size/1024/1024,2),'MB')
print('SUCCESS',len(D),len(natural),'vars',len(D.columns),'fractional',len(fracrows),'ubigeo variations',len(problem_codes),'trimmed',sum(trim_count.values()))
